__author__ = 'A'
import sys
sys.path.append('..')
sys.path.append('/home/bagnikita/ReliabilitySolver/build/bin/')
