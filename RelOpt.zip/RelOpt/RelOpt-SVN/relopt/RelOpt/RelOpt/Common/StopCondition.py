import math

class StopCondition:
    def __init__(self):
		pass
    def checkStopCondition(self, currVal, maxVal):
        if True: 
            return True
        return False
