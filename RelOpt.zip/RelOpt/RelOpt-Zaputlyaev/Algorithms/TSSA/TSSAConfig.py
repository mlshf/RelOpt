from Common.AlgConfig import AlgConfig

class TSSAConfig(AlgConfig):
    def __init__(self):
        AlgConfig.__init__(self)
		

    def LoadFromXmlNode(self, node):
        pass