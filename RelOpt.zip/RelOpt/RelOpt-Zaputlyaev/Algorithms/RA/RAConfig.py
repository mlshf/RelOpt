from Common.AlgConfig import AlgConfig

class RAConfig(AlgConfig):
    def __init__(self):
        AlgConfig.__init__(self)
		

    def LoadFromXmlNode(self, node):
        pass